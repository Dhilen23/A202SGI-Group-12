package com.example.pdzcarrental;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CarsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars);
    }
}